/**
 * ...
 * @author General
 */

ErrorMarker = function(game) {
	this.game = game;
	
}

ErrorMarker.prototype = {
	init: function () {
	
	},
	f2: function () {
	
	},
	f3: function () {
	
	}
}