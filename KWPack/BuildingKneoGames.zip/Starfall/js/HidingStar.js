/**
 * ...
 * @author General
 */

HidingStar = function(game) {
	this.game = game;
	this.fr0 = 0;
	this.star = null;
	this.scalesAr = [0.2,0.35,0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.0, 0.9, 1.0,0.9,1.0];

	this.hideTimer = this.game.time.create(false);
	this.hideTimerRepeatCount = this.scalesAr.length;
	this.hideTimerDelay = 30;
}

HidingStar.prototype = {
	init: function () {
		this.star = this.game.add.sprite(0,0,'PIC_ALL_ART','HidingStar0000');
		this.star.anchor.setTo(0.5,0.53);
		this.star.visible = false;
		
		this.fr0 = this.star.frame;
		
	},
	doScaleTimer: function () {
		this.TTL++;
		if (this.TTL < this.scalesAr.length) {
			this.star.scale.set(this.scalesAr[this.TTL],this.scalesAr[this.TTL]);
			this.hideTimer.add(this.hideTimerDelay,this.doScaleTimer,this);
			this.hideTimer.start();
		}
		else{
			this.onScaleComplete();
		}
	},
	onScaleComplete: function () {
		this.twn = this.game.add.tween(this.star);
		this.twn.to({alpha:0},500);
		this.twn.start();
	},
	onTweenComplete: function () {
		this.star.visible = false;
	},
	forceHide: function () {
		//tm.stop();
		//twn.cancelTweening();
		this.hideTimer.stop();
		if (this.twn){this.twn.stop()}
		
		this.star.visible = false;
	},
	showOnScreen: function (ax, ay) {
		console.log('showOnScreen '+ax+' '+ay);
		this.star.x = ax;
		this.star.y = ay;
		this.star.rotation = Math.floor(Math.random() * 360);
		this.star.alpha = 1;
		//twn.cancelTweening();
		if (this.twn){this.twn.stop()}
		this.TTL = 0;
	//	tm.reset();
	//	tm.start();
		this.hideTimer.stop();
	
		this.star.scale.set(this.scalesAr[this.TTL],this.scalesAr[this.TTL]);
		this.star.visible = true;
		
		this.hideTimer.add(this.hideTimerDelay,this.doScaleTimer,this);
		this.hideTimer.start();
	}
}