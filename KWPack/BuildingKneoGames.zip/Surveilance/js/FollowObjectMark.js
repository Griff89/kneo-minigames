/**
 * ...
 * @author General
 */

FollowObjectMark = function(game, comlFun) {
	this.game = game;
	this.completeFunc = comlFun;
	
	this.hideTimer = game.time.create(false);
	this.targetObject = null;
	
	this.sprite = null;
}

FollowObjectMark.prototype = {
	init: function () {
		this.sprite = this.game.add.sprite(0,0,'PIC_OBJ_MARK');
		this.sprite.animations.add('appear',[0,1,2,3,4,5,6,7,8,9]);
		this.sprite.animations.add('show',[9,10,11,12,13,14,15,16,17]);
		this.sprite.events.onAnimationComplete.add(this.startLoopAnim,this);
		this.sprite.anchor.setTo(0.5,0.5);
	},
	onHideComplete: function () 
	{
		this.completeFunc();
		this.hide();
	},
	
	showFigure: function (mob) 
	{
		this.targetObject = mob;
		this.sprite.x = mob.ptX+mob.content.width/2;
		this.sprite.y = mob.ptY+mob.content.height/2;
		
		this.sprite.animations.play('appear',30);
	//	circle.gotoAndPlay(1);
		
		this.sprite.visible = true;
	//	par.addChild(this);
		
		this.hideTimer.stop();
		this.hideTimer.add(1500,this.onHideComplete,this);
		this.hideTimer.start();
	},
	
	hide: function () {
		this.sprite.visible = false;
		this.sprite.animations.stop();
	},	
	startLoopAnim: function () {
		this.sprite.animations.play('show',30);
		console.log('startLoopAnim');
	},
	f3: function () {
	
	}
}